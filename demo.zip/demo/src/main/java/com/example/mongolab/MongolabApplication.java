package com.example.mongolab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongolabApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongolabApplication.class, args);
	}

}
