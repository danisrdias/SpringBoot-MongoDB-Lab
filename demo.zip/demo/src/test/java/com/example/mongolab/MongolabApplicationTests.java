package com.example.mongolab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongolabApplicationTests {

	@Test
	void contextLoads() {
	}

}
